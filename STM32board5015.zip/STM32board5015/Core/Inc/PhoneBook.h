/*
 * PhoneBook.h
 *
 *  Created on: Oct 8, 2020
 *      Author: proizvodstvoograzdenij
 */

#ifndef SRC____INC_PHONEBOOK_H_
#define SRC____INC_PHONEBOOK_H_
#include "stm32f1xx_hal.h"
#include "defs.h"

extern              SetsStruct Settings;
extern 				UART_HandleTypeDef huart2;

class PhoneBook {

public:
	PhoneBook();

	uint16_t 	BookIndex;
	uint16_t 	ZippedNumber[3];  //[0x0792,0x1746,0x6009]
	char* 		RAWNumber;
	bool 		ZipNum(char*, uint8_t *);
	bool 		FindNum(char*);
	bool 		FindNumByIndex(uint16_t);
	bool 		DelNum(char*, uint16_t*);
	bool 		FindPosition(char*, uint16_t*);
	bool 		ExtractPosition(char*, uint8_t, uint16_t*);
	bool 		AddNum(char*, uint16_t*);
	bool 		DelNum(uint16_t);
	bool 		AddNum(uint16_t, char*);
	bool 		ReadSettings();
	bool 		FactorySettings();
	bool 		SaveSettings();
	bool 		ClearMemory();

private:
	bool 		_isDigit(char);
	uint32_t	_GetPage(uint16_t);

};

#endif /* SRC____INC_PHONEBOOK_H_ */
