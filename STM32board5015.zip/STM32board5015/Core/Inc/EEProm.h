/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __EEPROM_H
#define __EEPROM_H

/* Includes ------------------------------------------------------------------*/
#include "stm32f1xx_hal.h"
#include "defs.h"
#include "stm32f1xx_hal_flash.h"

/* Exported constants --------------------------------------------------------*/
extern 				  IWDG_HandleTypeDef hiwdg;
/* EEPROM emulation firmware error codes */
#define EE_OK      (uint32_t)HAL_OK
#define EE_ERROR   (uint32_t)HAL_ERROR
#define EE_BUSY    (uint32_t)HAL_BUSY
#define EE_TIMEOUT (uint32_t)HAL_TIMEOUT

/* Define the size of the sectors to be used */
#define PAGE_SIZE               (uint32_t)0x400  /* Page size = 1024Byte */

/* Device voltage range supposed to be [2.7V to 3.6V], the operation will
   be done by word  */
#define VOLTAGE_RANGE           (uint8_t)VOLTAGE_RANGE_3

/* Page status definitions */
#define ERASED                ((uint16_t)0xFFFF)     /* Page is empty */

/* Exported types ------------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */
uint16_t EE_Start(void);
uint16_t EE_ReadVariable(uint32_t VirtAddress);
uint16_t EE_WriteVariable(uint32_t VirtAddress, uint16_t Data);
void 	 EE_DelVariable(uint32_t*, uint32_t);
void 	 EE_ClearPage(uint32_t);

#endif /* __EEPROM_H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
