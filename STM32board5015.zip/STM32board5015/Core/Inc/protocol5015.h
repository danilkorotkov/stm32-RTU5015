/*
 * protocol5015.h
 *
 *  Created on: Oct 8, 2020
 *      Author: proizvodstvoograzdenij
 */

#ifndef SRC_PROTOCOL5015_H_
#define SRC_PROTOCOL5015_H_

#include "stm32f1xx_hal.h"

#include "defs.h"
#include "MC35i.h"
#include "PhoneBook.h"
#include <string>
using namespace std;

extern                SetsStruct Settings;
extern                MC35i gsm;
extern                PhoneBook PB;
extern bool           ResetTimeout;
extern 				  TIM_HandleTypeDef htim1;
extern 				  UART_HandleTypeDef huart2;

void CheckNum         (char *, char *);
bool CheckSMS         (char*);
bool FindSeq          (uint8_t*, string &, char*, uint8_t);

bool ErrorText		  (char*);
void Relay1			  (void);
bool Relay2           (bool, char*);
bool 				  _isDigit(char);
bool 				  Reset(char *, bool);
bool 				  ConfTel(char*, uint8_t*);
bool 				  PwdChange(char* , uint8_t *);
bool 				  GotRes (char*);
bool 				  Status(char*);


#endif /* SRC_PROTOCOL5015_H_ */
