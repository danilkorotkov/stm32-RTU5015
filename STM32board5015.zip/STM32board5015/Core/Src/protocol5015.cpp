/*
 * protocol5015.cpp
 *
 *  Created on: Oct 8, 2020
 *      Author: proizvodstvoograzdenij
 */

#include "protocol5015.h"
#include "defs.h"
#include "main.h"

#include <cstring>
#include <string>
using namespace std;

void CheckNum(char *phone, char *text){
  uint8_t i = 0;
  string LOG;
  if ( Settings.AccessAlarm == 1) {
	  LOG = "Incoming Call, Access for all\n";
	  HAL_UART_Transmit(&huart3, (uint8_t*)(LOG.c_str()), strlen(LOG.c_str()), 1000);
	  Relay1();
  }
	else{
	  LOG = "Restricted Access, checking phone num\n";
	  HAL_UART_Transmit(&huart3, (uint8_t*)(LOG.c_str()), strlen(LOG.c_str()), 1000);

	  if (strlen(phone)<11){
		  LOG = "Possible spam, rejected\n";
		  HAL_UART_Transmit(&huart3, (uint8_t*)(LOG.c_str()), strlen(LOG.c_str()), 1000);
		  return;
	  } // отсекаем неформатные номера
	  while(strlen(phone)>11){			//убираем + для формата 999-999-99-99
		  for (i=0; i<strlen(phone); i++){phone[i]=phone[i+1];}
		  phone[strlen(phone)] = 0;
		}

	  i = strlen(phone) - 1;
	  if ( i>9 &&  PB.ZipNum(phone, &i) ) {if ( PB.FindNum(text) ){Relay1();return;}}
	}

	  LOG = "Num is not found, rejected\n";
	  HAL_UART_Transmit(&huart3, (uint8_t*)(LOG.c_str()), strlen(LOG.c_str()), 1000);
	  ErrorText(text);
}

bool CheckSMS(char* text){
  string Sequence = "1234#RESET";
  uint8_t i = 0;

  if( FindSeq(&i, Sequence, text, i) && !ResetTimeout) {
	  return Reset(text, false);
  }

  if( !(text[0] == Settings.Pass[0] &&\
		text[1] == Settings.Pass[1] &&\
		text[2] == Settings.Pass[2] &&\
		text[3] == Settings.Pass[3] &&\
		text[4] == '#') ){
	  return ErrorText(text);
  }

  i = 5;
  Sequence = "FSET#";
  if( FindSeq(&i, Sequence, text, i) ) {
	  return Reset(text, true);
  }

  //tel manipulation
  i = 5;
  Sequence = "TEL";
  if( FindSeq(&i, Sequence, text, i) ) {
	  return ConfTel(text, &i);
  }

  //pwd change 1234#PWD6666#PWD6666#
  Sequence = "PWD";
  i = 5;
  if( FindSeq(&i, Sequence, text, i) ) {
	  return PwdChange(text, &i);
  }

  // доступ к реле 1234#AA# 1-all  1234#AU# 0=auth
  Sequence = "AA#";
  i = 5;
  if( FindSeq(&i, Sequence, text, i) ) {
    strcpy( text, (const char *)AA );
    Settings.AccessAlarm = 1;
    PB.SaveSettings();
    return true;
  }

  Sequence = "AU#";
  i = 5;
  if( FindSeq(&i, Sequence, text, i) ) {
    strcpy( text, (const char *)AU );
    Settings.AccessAlarm = 0;
    PB.SaveSettings();
    return true;
  }

  //время реле
  Sequence = "GOT";
  i = 5;
  if( FindSeq(&i, Sequence, text, i) ){
    if  (text[i] == '?') {
      return GotRes(text);
    }
    else{
      if (text[i+2] == '#' && _isDigit(text[i]) && _isDigit(text[i+1])) {
        Settings.RelayOnTime = (uint8_t(text[i] - 0x30)) * 10 + (uint8_t(text[i+1] - 0x30));
        if (Settings.RelayOnTime<99){
        	PB.SaveSettings();
        	ReloadRelayTimer();
        	return GotRes(text);
        }else {
        	PB.ReadSettings();
          return ErrorText(text);
        }
      }
    }
  }

  //статус
  Sequence = "CSQ?";
  i = 5;
  if( FindSeq(&i, Sequence, text, i) ){
	  return Status(text);
  }

  //второе реле
  i = 4;
  Sequence = "#ON#";
  if( FindSeq(&i, Sequence, text, i) ){
	  return Relay2(true,  text);
  }
  i = 4;
  Sequence = "#OFF#";
  if( FindSeq(&i, Sequence, text, i) ){
	  return Relay2(false,  text);
  }

  return ErrorText(text);
}

bool ConfTel(char* t, uint8_t * i){
  uint16_t pos = 0;
  uint8_t j = 0;
  string Sequence = "?";

//search num by position or del
    if ( t[(*i)+3] == '?' ||  t[(*i)+3] == '#') {
      if ( !PB.ExtractPosition(t, *i, &pos) ) {return ErrorText(t);}
      if ( t[(*i)+3] == '?' ) {return PB.FindPosition (t, &pos);} else {return PB.DelNum(t, &pos);}
    }
//search num by position or del end

//find by num
    j = *i;  //Sequence = F("?");
    if( FindSeq(&j, Sequence, t, (*i)+11 ) ) {
      //if ( j - (*i) > 11) { (*i) += j - (*i) - 11;}
      j -=2;
      if (PB.ZipNum(t, &j)) {return PB.FindNum(t);}
      else { return ErrorText(t);}
    }
//find by num end

//add num
    Sequence = "#";
    j = *i;
    if( !FindSeq(&j, Sequence, t, (*i)+11 ) ){ return ErrorText(t);}

    *i = j;
    j -= 2;
    if ( t[(*i)+3] == '#') {
      if ( !PB.ExtractPosition(t, *i, &pos) ) {
    	  return ErrorText(t);
      }
      if (PB.ZipNum(t, &j)) {
    	  return PB.AddNum(t, &pos);
      }else {return ErrorText(t);}
    }else { return ErrorText(t);}
}
//-------------------------------------------------------------------
//-------------------------------------------------------------------
//-------------------------------------------------------------------
//-------------------------------------------------------------------

bool ErrorText (char* text)	{strcpy( text, "Error" ); return false;};


bool Reset(char *text, bool r){
  if (!r) {
	  strcpy(Settings.Pass, "1234");
	  PB.SaveSettings();
  }else{
	  strcpy(Settings.Pass, "1234");
	  Settings.RelayOnTime = 1;
	  Settings.AccessAlarm = 0;
	  ReloadRelayTimer();
	  PB.SaveSettings();
	  PB.ClearMemory();
  }
  strcpy(text, (const char *)RESETED);
  return true;
}

bool GotRes (char* t){
  uint8_t i;
  char temp[6] = "";

  if (Settings.RelayOnTime >0){
	  strcpy( t, (const char *)tRELAY );
	  itoa(Settings.RelayOnTime/2, temp, 10);

	  strcat(t,temp);

	  i=strlen(t);

	  t[i] = '.';
	  t[i+1] = char('0' + ((Settings.RelayOnTime % 2)*5) );
	  t[i+2] = 0;

  }else {strcpy( t, (const char *)latchRELAY );}
  return true;
}

bool Status(char* t){
    string mess;

    mess = CELL;
    mess += to_string(100*gsm.CellLevel()/31) + ("%\n");

    HAL_IWDG_Refresh(&hiwdg);
    if (HAL_GPIO_ReadPin(Relay1_GPIO_Port, Relay1_Pin) == GPIO_PIN_SET) {mess += RELAY1ON;}
    else {mess += RELAY1OFF;}

    if (HAL_GPIO_ReadPin(Relay2_GPIO_Port, Relay2_Pin) == GPIO_PIN_SET) {mess += RELAY2ON;}
    else {mess += RELAY2OFF;}

    strcpy(t, mess.c_str());
    HAL_IWDG_Refresh(&hiwdg);
    return true;
}

bool PwdChange(char* t, uint8_t *i){
  uint8_t k;
  //1234#PWD[6]666#PWD6666#
  *i -= 3;
  for (uint8_t j=0; j<8; j++){
    if ( t[(*i) + j] == t[(*i) + 8 + j] ) {
    	//asm("nop");
    }
    else {j=8; return ErrorText(t);}
  }

  *i += 3;
  for (uint8_t j=0; j<4; j++){
    Settings.Pass[j]=t[(*i) + j];
  }

  PB.SaveSettings();

  strcpy( t, (const char *)sPASS );
  k=strlen(t);
  for (uint8_t j=0; j<5; j++){
    t[k+j] = Settings.Pass[j];
    if (j==4){t[k+j+1] = 0;}
  }

  return true;
}

void Relay1(){
	string LOG;
	uint32_t status = 0;
	LOG = "Relay 1 procedure\n";
	HAL_UART_Transmit(&huart3, (uint8_t*)(LOG.c_str()), strlen(LOG.c_str()), 1000);
	HAL_IWDG_Refresh(&hiwdg);

	if (Settings.RelayOnTime == 0){
		LOG = "Relay 1 is toggled\n";
		HAL_UART_Transmit(&huart3, (uint8_t*)(LOG.c_str()), strlen(LOG.c_str()), 1000);
		HAL_GPIO_TogglePin(Relay1_GPIO_Port, Relay1_Pin);
		HAL_GPIO_TogglePin(Led1_GPIO_Port, Led1_Pin);
		return;
	}

	LOG = "Relay 1 is ON!\n";
	HAL_UART_Transmit(&huart3, (uint8_t*)(LOG.c_str()), strlen(LOG.c_str()), 1000);
	HAL_GPIO_WritePin(Relay1_GPIO_Port, Relay1_Pin, GPIO_PIN_SET);

	LOG = "Led 1 is ON!\n";
	HAL_UART_Transmit(&huart3, (uint8_t*)(LOG.c_str()), strlen(LOG.c_str()), 1000);
	HAL_GPIO_WritePin(Led1_GPIO_Port, Led1_Pin, GPIO_PIN_RESET);

	__HAL_TIM_CLEAR_IT(&htim1, TIM_IT_UPDATE);
	status = HAL_TIM_Base_Start_IT(&htim1);
	LOG = "HAL_TIM_Base_Start_IT(&htim1) = " + to_string(status) + "\n";
	HAL_UART_Transmit(&huart3, (uint8_t*)(LOG.c_str()), strlen(LOG.c_str()), 1000);

}

bool Relay2(bool r, char* t){
	string LOG;
	if (r) {
		LOG = "Relay 2 is ON!\n";HAL_UART_Transmit(&huart3, (uint8_t*)(LOG.c_str()), strlen(LOG.c_str()), 500);
		HAL_GPIO_WritePin(Relay2_GPIO_Port, Relay2_Pin, GPIO_PIN_SET);

		LOG = "Led 2 is ON!\n";HAL_UART_Transmit(&huart3, (uint8_t*)(LOG.c_str()), strlen(LOG.c_str()), 1000);
		HAL_GPIO_WritePin(Led2_GPIO_Port, Led2_Pin, GPIO_PIN_RESET);

		strcpy( t, (const char *)RELAY2ON  );
  }
  else{
	  LOG = "Relay 2 is OFF!\n";HAL_UART_Transmit(&huart3, (uint8_t*)(LOG.c_str()), strlen(LOG.c_str()), 500);
	  HAL_GPIO_WritePin(Relay2_GPIO_Port, Relay2_Pin, GPIO_PIN_RESET);

	  LOG = "Led 2 is OFF!\n";HAL_UART_Transmit(&huart3, (uint8_t*)(LOG.c_str()), strlen(LOG.c_str()), 1000);
	  HAL_GPIO_WritePin(Led2_GPIO_Port, Led2_Pin, GPIO_PIN_SET);

	  strcpy( t, (const char *)RELAY2OFF );}
  return true;
}

bool FindSeq(uint8_t *index, string &Sequence, char *t, uint8_t from = 0){
      uint8_t i = from;
      uint8_t j = 0;
      bool found = false;
      while (t[i] && !found) {
      if(t[i] == Sequence[j]) {
        i++; j++;
        HAL_IWDG_Refresh(&hiwdg);
        if ( j == Sequence.length() ) {found = true;}
      } else {i++; j = 0;}
      }
      *index = i;
      return found;
}
bool _isDigit(char digit){
	return (digit >= 0x30 && digit <= 0x39);
}
