/*
 * defs.h
 *
 *  Created on: Oct 6, 2020
 *      Author: Danil
 */

#ifndef INC_DEFS_H_
#define INC_DEFS_H_

#include "stm32f1xx_hal.h"


#define CELL          "Сеть "
#define tRELAY        "Реле, сек "
#define latchRELAY    "Реле как выключатель"
#define RELAY1ON      "Реле1 ВКЛ\n"
#define RELAY1OFF     "Реле1 ВЫКЛ\n"
#define RELAY2ON      "Реле2 ВКЛ"
#define RELAY2OFF     "Реле2 ВЫКЛ"
#define sPASS         "Пароль: "
#define AA            "Доступен всем"
#define AU            "Доступ по списку"
#define ADDED         "Добавлен:"
#define RESETED       "Сброс"
#define DELETED       "Удален: "
#define MEMCELL       " Ячейка"
#define NOTFOUND      " Не найден"
#define AlARM1        "Тревога 1.\n"
#define AlARM2        "Тревога 2. "
#define sINPUT1       "ВХОД1 "
#define sINPUT2       "ВХОД2 "
#define sNC           "NC\n"
#define sNO           "NO\n"

#define Capacity      680

#define PhoneLen 13
#define SMStxtLen 70

#define bitRead(value, bit) (((value) >> (bit)) & 0x01)
#define bitWrite(value, bit, bitvalue) (bitvalue ? bitSet(value, bit) : bitClear(value, bit))
#define bitSet(value, bit) ((value) |= (1UL << (bit)))
#define bitClear(value, bit) ((value) &= ~(1UL << (bit)))

#define BaseAddress 0x8000000
#define PageSize 	(uint32_t)0x400
#define BankSwap 	BaseAddress + PageSize*(59-1)
#define Bank170 	BaseAddress + PageSize*(60-1)
#define Bank340 	BaseAddress + PageSize*(61-1)
#define Bank510 	BaseAddress + PageSize*(62-1)
#define Bank680 	BaseAddress + PageSize*(63-1)
#define SettBank 	BaseAddress + PageSize*(64-1)

struct SetsStruct {                   // Создаем пользовательскую структуру
  char Pass[4]= {'1','2','3','4'};    // Пароль модуля
  uint8_t RelayOnTime = 1;            // Время работы реле в полусекундах
  uint8_t AccessAlarm = 0;			  //1все/0только в списке
};

#endif /* INC_DEFS_H_ */
