/*
 * EEProm.cpp
 *
 *  Created on: Oct 9, 2020
 *      Author: proizvodstvoograzdenij
 */

#include "EEProm.h"


uint16_t EE_ReadVariable(uint32_t VirtAddress)
{
      return (*(__IO uint16_t*)(VirtAddress));

}

uint16_t EE_WriteVariable(uint32_t VirtAddress, uint16_t Data)
{
	HAL_StatusTypeDef status;
	HAL_FLASH_Unlock(); // разблокировать флеш

	status = HAL_FLASH_Program(FLASH_TYPEPROGRAM_HALFWORD, VirtAddress, Data);

    HAL_FLASH_Lock(); // заблокировать флеш

    return uint16_t(status);
}

void EE_DelVariable(uint32_t* SkipAddress, uint32_t address){
	uint16_t PageRead[64];
	uint8_t i;

	//перегоним в оперативу 1кб страницу, параллельно затирая искомый номер
	for(i=0; i<64; i++){
		if ( (address + i*2) == SkipAddress[0] || (address + i*2) == SkipAddress[1] || (address + i*2) == SkipAddress[2] ){
			PageRead[i] = ERASED;
		}
		else {PageRead[i] = EE_ReadVariable(address + i*2);}
	}

	//стираем
	EE_ClearPage(address);

	//из оперативы обратно на страницу  только не стертые значения
	HAL_FLASH_Unlock();

	for(i=0; i<64; i++){
		if (PageRead[i] != ERASED) { EE_WriteVariable(address +i*2, PageRead[i]);}
	}
	HAL_FLASH_Lock(); // заблокировать флеш

}

void EE_ClearPage(uint32_t address){
	uint32_t page_error = 0;

	static FLASH_EraseInitTypeDef EraseInitStruct; 		// структура для очистки флеша

	EraseInitStruct.TypeErase = FLASH_TYPEERASE_PAGES; // постраничная очистка, FLASH_TYPEERASE_MASSERASE - очистка всего флеша
	EraseInitStruct.PageAddress = address; 				// адрес страницы
	EraseInitStruct.NbPages = 1;                       // кол-во страниц для стирания

	HAL_IWDG_Refresh(&hiwdg);
	HAL_FLASH_Unlock();
	HAL_FLASHEx_Erase(&EraseInitStruct, &page_error);
	HAL_FLASH_Lock(); // заблокировать флеш
	HAL_IWDG_Refresh(&hiwdg);
}

uint16_t EE_Start(void)
{
  return HAL_OK;
}
