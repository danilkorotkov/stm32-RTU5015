/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "MC35i.h"
#include "defs.h"
#include "protocol5015.h"
#include "PhoneBook.h"

#include <cstring>
#include <string>
using namespace std;
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
IWDG_HandleTypeDef hiwdg;

TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim2;

UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;
UART_HandleTypeDef huart3;

/* USER CODE BEGIN PV */
SetsStruct Settings;
MC35i gsm(PwrKey_Pin, PwrKey_GPIO_Port);
PhoneBook PB;
char IncomingPhone[PhoneLen];               // Объявляем строку (массив) для получения адреса отправителя SMS
char SMStxt[SMStxtLen];                     // Объявляем строку (массив) для получения текста SMS.
uint8_t PhoneComp[6];                       //сжатый номер

uint32_t ResetPeriod   = 120000; 			// 2 минуты на ресет пароля
bool     ResetTimeout  = false;  			// время на ресет истекло true / не истекло false
uint32_t PollStart     = 0;   	 			// опрос
uint32_t PollTimeout   = 3000;   			// опрос
bool 	 ResetIsOn	   = false;

string LOG;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_IWDG_Init(void);
static void MX_TIM1_Init(uint32_t=0);
static void MX_TIM2_Init(uint32_t=10000);
static void MX_USART1_UART_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_USART3_UART_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_IWDG_Init();
  MX_TIM1_Init();
  MX_TIM2_Init();
  MX_USART1_UART_Init();
  MX_USART2_UART_Init();
  MX_USART3_UART_Init();
  /* USER CODE BEGIN 2 */
  ReloadStatusTimer(1000);

    if (!PB.ReadSettings()){
  	  LOG = "Hello World!\n";
  	  HAL_UART_Transmit(&huart3, (uint8_t*)(LOG.c_str()), strlen(LOG.c_str()), 1000);
  	  PB.SaveSettings();
    }

    HAL_Delay(2000);
    LOG = "Welcome! v1.15\n";
    HAL_UART_Transmit(&huart3, (uint8_t*)(LOG.c_str()), strlen(LOG.c_str()), 1000);

    LOG = "Pass= " + string(Settings.Pass) + "\n";
    HAL_UART_Transmit(&huart3, (uint8_t*)(LOG.c_str()), strlen(LOG.c_str()), 1000);

    LOG = "Relay Delay= " + to_string(Settings.RelayOnTime / 2) + "." + to_string(5 * (Settings.RelayOnTime % 2)) + "s\n";
    HAL_UART_Transmit(&huart3, (uint8_t*)(LOG.c_str()), strlen(LOG.c_str()), 1000);

    if (Settings.AccessAlarm == 0){LOG = "Auth access only\n";}
    else if (Settings.AccessAlarm == 1){LOG = "Access for all\n";}
    else{ LOG = "Access status error!";}

    HAL_UART_Transmit(&huart3, (uint8_t*)(LOG.c_str()), strlen(LOG.c_str()), 1000);

    HAL_IWDG_Refresh(&hiwdg);

    HAL_TIM_Base_Start_IT(&htim2);
    LOG = "Timer 2 started\n";
    HAL_UART_Transmit(&huart3, (uint8_t*)(LOG.c_str()), strlen(LOG.c_str()), 1000);

    LOG = "Sim800c connecting...\n";
    HAL_UART_Transmit(&huart3, (uint8_t*)(LOG.c_str()), strlen(LOG.c_str()), 1000);
    while(!gsm.begin(huart2)) {HAL_Delay(1000);HAL_IWDG_Refresh(&hiwdg);}

    LOG = "Sim800c connected\n";
    HAL_UART_Transmit(&huart3, (uint8_t*)(LOG.c_str()), strlen(LOG.c_str()), 1000);

    ReloadRelayTimer();

    ReloadStatusTimer(3000);

    while(gsm.Status()!=GSM_OK) {HAL_Delay(1000); HAL_IWDG_Refresh(&hiwdg);} // Ждём завершения регистрации модема в сети оператора связи.
    LOG = "GSM Network connected\n";
    HAL_UART_Transmit(&huart3, (uint8_t*)(LOG.c_str()), strlen(LOG.c_str()), 1000);

    ReloadStatusTimer(50000);

    PollStart = HAL_GetTick();

    LOG = "Loop started\n";
    HAL_UART_Transmit(&huart3, (uint8_t*)(LOG.c_str()), strlen(LOG.c_str()), 1000);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  if ( ((HAL_GetTick() - PollStart) > PollTimeout) && !ResetIsOn )
	  	  	  {
	  	  	  	    PollStart = HAL_GetTick();
	  	  	  	    HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13);

	  	  			if(gsm.CallAvailable(IncomingPhone)){                  // Функция CALLavailable() возвращает true если есть входящий дозванивающийся вызов.
	  	  				HAL_IWDG_Refresh(&hiwdg);

	  	  				gsm.CallEnd();
	  	  				LOG = "Incoming Call = " + string(IncomingPhone) + "\n";
	  	  				HAL_UART_Transmit(&huart3, (uint8_t*)(LOG.c_str()), strlen(LOG.c_str()), 1000);

	  	  				CheckNum(IncomingPhone, SMStxt);
	  	  			}

	  	  			if(gsm.SmsAvailable()){
	  	  				HAL_IWDG_Refresh(&hiwdg);
	  	  				ReloadStatusTimer(5000);

	  	  				gsm.SMSread(SMStxt, IncomingPhone);
	  	  				LOG = "Incoming message num = " + string(IncomingPhone) + "\n";
	  	  				HAL_UART_Transmit(&huart3, (uint8_t*)(LOG.c_str()), strlen(LOG.c_str()), 1000);

	  	  				LOG = "Incoming message = " + string(SMStxt) + "\n";
	  	  				HAL_UART_Transmit(&huart3, (uint8_t*)(LOG.c_str()), strlen(LOG.c_str()), 1000);

	  	  				CheckSMS(SMStxt);

	  	  				if ( SMStxt[0] != 'E' && IncomingPhone[0] != 'E'){gsm.SMSsend(SMStxt, IncomingPhone);}

	  	  				ReloadStatusTimer(50000);
	  	  			}
	  	  	  }



	  	  	  if (!ResetTimeout)
	  	  	  {                                    // Отключаем сброс пароля
	  	  	  	    if (HAL_GetTick() > ResetPeriod)
	  	  	  	    	{
	  	  	  	        ResetTimeout = true;
	  	  	  	        LOG = "Reset Timeout...\n";
	  	  	  	    	HAL_UART_Transmit(&huart3, (uint8_t*)(LOG.c_str()), strlen(LOG.c_str()), 1000);
	  	  	  	    	}
	  	  	  }
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI|RCC_OSCILLATORTYPE_LSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.LSIState = RCC_LSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI_DIV2;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL16;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief IWDG Initialization Function
  * @param None
  * @retval None
  */
static void MX_IWDG_Init(void)
{

  /* USER CODE BEGIN IWDG_Init 0 */

  /* USER CODE END IWDG_Init 0 */

  /* USER CODE BEGIN IWDG_Init 1 */

  /* USER CODE END IWDG_Init 1 */
  hiwdg.Instance = IWDG;
  hiwdg.Init.Prescaler = IWDG_PRESCALER_256;
  hiwdg.Init.Reload = 1562;
  if (HAL_IWDG_Init(&hiwdg) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN IWDG_Init 2 */

  /* USER CODE END IWDG_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(uint32_t RepetitionCounter)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 6399;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 5000;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = RepetitionCounter;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(uint32_t Period)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 6399;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = Period;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief USART3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART3_UART_Init(void)
{

  /* USER CODE BEGIN USART3_Init 0 */

  /* USER CODE END USART3_Init 0 */

  /* USER CODE BEGIN USART3_Init 1 */

  /* USER CODE END USART3_Init 1 */
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 115200;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART3_Init 2 */

  /* USER CODE END USART3_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, Relay2_Pin|Relay1_Pin|StatusLed_Pin|PwrKey_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, Led1_Pin|Led2_Pin, GPIO_PIN_SET);

  /*Configure GPIO pins : Relay2_Pin Relay1_Pin StatusLed_Pin PwrKey_Pin */
  GPIO_InitStruct.Pin = Relay2_Pin|Relay1_Pin|StatusLed_Pin|PwrKey_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : Led1_Pin Led2_Pin */
  GPIO_InitStruct.Pin = Led1_Pin|Led2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */
void ReloadStatusTimer(uint32_t Period){
	LOG = "Status Timer2 Period = " + to_string(Period / 10) + "ms\n";
	HAL_UART_Transmit(&huart3, (uint8_t*)(LOG.c_str()), strlen(LOG.c_str()), 1000);

	HAL_TIM_Base_Stop_IT(&htim2);
	MX_TIM2_Init(Period);

	HAL_TIM_Base_Start_IT(&htim2);
}

void ReloadRelayTimer(void){
	HAL_TIM_Base_Stop(&htim1);
	HAL_TIM_Base_Stop_IT(&htim1);
	HAL_GPIO_WritePin(Relay1_GPIO_Port, Relay1_Pin, GPIO_PIN_RESET);

	if (Settings.RelayOnTime > 0){
		MX_TIM1_Init((uint32_t)Settings.RelayOnTime - 1);
		LOG = "Repetition Counter Timer  = " + to_string(htim1.Init.RepetitionCounter) + "\n";
		HAL_UART_Transmit(&huart3, (uint8_t*)(LOG.c_str()), strlen(LOG.c_str()), 1000);
		HAL_IWDG_Refresh(&hiwdg);
	}else{
		MX_TIM1_Init();
		LOG = "Repetition Counter Timer is OFF \n";
		HAL_UART_Transmit(&huart3, (uint8_t*)(LOG.c_str()), strlen(LOG.c_str()), 1000);
		HAL_IWDG_Refresh(&hiwdg);
	}
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim){
	if(htim->Instance == TIM1) //check if the interrupt comes from TIM1
	{
		uint32_t status =HAL_TIM_Base_Stop_IT(&htim1);

		LOG = "HAL_TIM_Base_Stop_IT(&htim1) = " + to_string(status) + "\n";
		HAL_UART_Transmit(&huart3, (uint8_t*)(LOG.c_str()), strlen(LOG.c_str()), 100);

		HAL_GPIO_WritePin(Relay1_GPIO_Port, Relay1_Pin, GPIO_PIN_RESET);
		HAL_UART_Transmit(&huart3, (uint8_t*)("Relay 1 is OFF!\n"), strlen("Relay 1 is OFF!\n"), 100);

		HAL_GPIO_WritePin(Led1_GPIO_Port, Led1_Pin, GPIO_PIN_SET);
		HAL_UART_Transmit(&huart3, (uint8_t*)("Led 1 is OFF!\n"), strlen("Led 1 is OFF!\n"), 100);
		HAL_IWDG_Refresh(&hiwdg);
	}
	if(htim->Instance == TIM2) //check if the interrupt comes from TIM2
	{
		HAL_GPIO_TogglePin(StatusLed_GPIO_Port, StatusLed_Pin);
	}

}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
	LOG = "Error_Handler!\n";
	HAL_UART_Transmit(&huart3, (uint8_t*)(LOG.c_str()), strlen(LOG.c_str()), 1000);
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
