/*
 * PhoneBook.cpp
 *
 *  Created on: Oct 8, 2020
 *      Author: proizvodstvoograzdenij
 */

#include "PhoneBook.h"
#include "protocol5015.h"
#include "EEProm.h"
#include "main.h"

#include <cstring>
#include <string>
using namespace std;

PhoneBook::PhoneBook() {
	// TODO Auto-generated constructor stub

}

bool PhoneBook::_isDigit(char digit){
	return (digit >= 0x30 && digit <= 0x39);
}

bool PhoneBook::ZipNum(char* phone, uint8_t *j){
	for (uint8_t k = 0; k <=10; k++){
	  // проверяем что номер состоит из цифр
      if ( !(_isDigit(phone[(*j)-k])) ){
    	  k=-1;
    	  return false;
      }
   	}
// сжимаем номер в 3 полуслова
  ZippedNumber[2] = uint8_t(phone[(*j)-0] - 0x30) 				+\
		  	  	   (uint8_t(phone[(*j)-1] - 0x30)  << 4) 		+\
				   (uint8_t(phone[(*j)-2] - 0x30)  << 4*2) 		+\
				   (uint8_t(phone[(*j)-3] - 0x30)  << 4*3)		;
  ZippedNumber[1] = uint8_t(phone[(*j)-4] - 0x30) 				+\
		  	  	   (uint8_t(phone[(*j)-5] - 0x30)  << 4) 		+\
				   (uint8_t(phone[(*j)-6] - 0x30)  << 4*2) 		+\
				   (uint8_t(phone[(*j)-7] - 0x30)  << 4*3)		;
  ZippedNumber[0] = uint8_t(phone[(*j)-8] - 0x30) 				+\
		  	  	   (uint8_t(phone[(*j)-9] - 0x30)  << 4) 		+\
				   (uint8_t(phone[(*j)-10] - 0x30) << 4*2) 		+\
				   (						 0x00  << 4*3)		;
  return true;
}

bool PhoneBook::FindNum(char* text){
	 uint16_t i, j, pos;
	 bool found = false;
	 string mess;
	 uint32_t address;
	 string LOG;

	 j=0;
	 //перебор ячеек памяти
	  for(i=0; i<680; i++){
		//переключаем страницы
		HAL_IWDG_Refresh(&hiwdg);
		address = _GetPage(i);
		//LOG = "Check Position on Bank= " + to_string(j+1) + "\n";HAL_UART_Transmit(&huart3, (uint8_t*)(LOG.c_str()), strlen(LOG.c_str()), 1000);
		//определяем сдвиг в памяти и сравниваем со сжатым номером содержимое памяти
		if ( (i%2)==0 ){
			if (ZippedNumber[0] == EE_ReadVariable (6*j + address + 2) &&\
				ZippedNumber[1] == EE_ReadVariable (6*j + address	)  &&\
				ZippedNumber[2] == EE_ReadVariable (6*j + address + 6)	){found = true;}

		}else{
			if (ZippedNumber[0] == EE_ReadVariable (6*j + address - 2) &&\
				ZippedNumber[1] == EE_ReadVariable (6*j + address + 4) &&\
				ZippedNumber[2] == EE_ReadVariable (6*j + address + 2)	){found = true;}

		}
		j++;
		if (j > 169 ) { j = 0; } //  новый банк
		//если нашли - досрочный выход
        if (found){pos = i+1; i=681;}
	    }
	  //собираем сообщение с результатом
	  if (found){
	     mess = to_string( (pos)/100      )  +\
	    		to_string( ((pos)%100)/10 )  +\
				to_string( ((pos)%100)%10 )  ;
	     mess += MEMCELL;
	     strcpy(text, mess.c_str());
	     return true;
	   }else {
	     strcpy(text, (const char *)NOTFOUND);
	     return false;}
}

bool PhoneBook::FindPosition(char *text, uint16_t *pos){
  uint32_t address;
  uint8_t i;
  string mess;
  // если номер позиции не превышает максимальную
  if (*pos>Capacity) {ErrorText(text);}
  // определим страницу в памяти по номеру позиции
  address = _GetPage(*pos);

  // заготовка обратного сообщения
  mess = to_string(( (*pos)/100      )) +\
		 to_string(( ((*pos)%100)/10 )) +\
		 to_string(( ((*pos)%100)%10 )) + ':' + ' ';
  // чтение номера из памяти
    strcpy(text, mess.c_str());
  	i = (*pos) - 1;
	if ( (i%2)==0 ){
		ZippedNumber[0] = EE_ReadVariable(6*i + address + 2);
		ZippedNumber[1] = EE_ReadVariable(6*i + address	   );
		ZippedNumber[2] = EE_ReadVariable(6*i + address + 6);

	}else{
		ZippedNumber[0] = EE_ReadVariable(6*i + address - 2);
		ZippedNumber[1] = EE_ReadVariable(6*i + address + 4);
		ZippedNumber[2] = EE_ReadVariable(6*i + address + 2);
		}
	// если есть данные в памяти, то собираем дальше сообщение
	if ( ZippedNumber[2] != ERASED){
		for (i=0; i<3; i++){
			if (i==0){
				mess+=  to_string( (ZippedNumber[i] & 0x0F00)>>8 )  +\
						to_string( (ZippedNumber[i] & 0x00F0)>>4 )	+\
						to_string( (ZippedNumber[i] & 0x000F)    )	;
			}else{
				mess+=  to_string( (ZippedNumber[i] & 0xF000)>>12 ) 	+\
						to_string( (ZippedNumber[i] & 0x0F00)>>8  ) 	+\
						to_string( (ZippedNumber[i] & 0x00F0)>>4  )		+\
						to_string( (ZippedNumber[i] & 0x000F) 	  ) 	;
			}
		}
	}else{
		mess += ' ' + (const char*)NOTFOUND;
		strcpy(text,  mess.c_str());

		return true;
	}
	// переводим сообщение из строки
	strcpy(text, mess.c_str());
	HAL_IWDG_Refresh(&hiwdg);
	return true;
}

bool PhoneBook::ExtractPosition(char *text, uint8_t i, uint16_t *pos){
      string LOG;
	  //определяем номер позиции из текста сообщения с проверкой на цифры
	  if ( !_isDigit(text[i])  )        { return false;}
      *pos += ( uint8_t( text[i] - 0x30 ) ) * 100;

      if ( !_isDigit(text[(i)+1]) )      { return false;}
      *pos += ( uint8_t(text[(i)+1]  ) - 0x30 ) * 10;

      if ( !_isDigit(text[(i)+2]) )      { return false;}
      *pos += uint8_t(  text[(i)+2]  ) - 0x30;
      LOG = "Extracted Position = " + to_string(*pos) + "\n";HAL_UART_Transmit(&huart3, (uint8_t*)(LOG.c_str()), strlen(LOG.c_str()), 1000);
      return true;
}

bool PhoneBook::DelNum(char *text, uint16_t *pos){
	  uint32_t address;
	  uint8_t i;
	  string mess;
	  uint32_t SkipAddress[3];
	  uint16_t isEmpty;
	  //если позиция за пределами емкости -  выходим
	  if (*pos>Capacity) {ErrorText(text); return false;}
	  //страница с номером позиции
	  address = _GetPage(*pos);

		i = (*pos) - 1;
		//заполняем массив тремя адресами позиции телефона на флеше
		if ( (i%2)==0 ){
			SkipAddress[0] = 6*i + address + 2;
			SkipAddress[1] = 6*i + address	  ;
			SkipAddress[2] = 6*i + address + 6;
			isEmpty = EE_ReadVariable(6*i + address + 6);

		}else{
			SkipAddress[0] = 6*i + address - 2;
			SkipAddress[1] = 6*i + address + 4;
			SkipAddress[2] = 6*i + address + 2;
			isEmpty = EE_ReadVariable(6*i + address + 2);
			}
		//если не стерто уже - стереть
		if (isEmpty != ERASED){
			EE_DelVariable(SkipAddress, address);

	  }
	  //собираем ответное сообщение

	  mess =(const char *)DELETED  				   +\
	  	  	  to_string(char( (*pos)/100      ))   +\
	  	  	  to_string(char( ((*pos)%100)/10 ))   +\
	  	  	  to_string(char( ((*pos)%100)%10 ));
	  strcpy( text, mess.c_str());
	  HAL_IWDG_Refresh(&hiwdg);
	  return true;
}

bool PhoneBook::AddNum(char* text, uint16_t *pos){
	 uint16_t i;
	 string mess;
	 uint32_t address;
	 uint16_t isEmpty;
	 string LOG;

	 if (*pos>Capacity) {ErrorText(text);return false;}
	 if (FindNum(text)){return true;}
	  //страница с номером позиции
	 HAL_IWDG_Refresh(&hiwdg);
	 address = _GetPage(*pos);

	 i = (*pos) - 1;
	 LOG = "Cell PhoneBook = " + to_string(*pos) + "\n";HAL_UART_Transmit(&huart3, (uint8_t*)(LOG.c_str()), strlen(LOG.c_str()), 1000);

	 while (i>170){i -=170;}

	 LOG = "Cell in Bank = " + to_string(i) + "\n";HAL_UART_Transmit(&huart3, (uint8_t*)(LOG.c_str()), strlen(LOG.c_str()), 1000);

	 isEmpty = EE_ReadVariable(6*i + address + 2);
	 if (isEmpty != ERASED){
		 DelNum(text, &(*pos));
	 }

	 if ( (i%2)==0 ){
		EE_WriteVariable(6*i + address + 2, ZippedNumber[0]);
		EE_WriteVariable(6*i + address    , ZippedNumber[1]);
		EE_WriteVariable(6*i + address + 6, ZippedNumber[2]);
	 }else{
		EE_WriteVariable(6*i + address - 2, ZippedNumber[0]);
		EE_WriteVariable(6*i + address + 4, ZippedNumber[1]);
		EE_WriteVariable(6*i + address + 2, ZippedNumber[2]);
		}

	  //собираем ответное сообщение

	 mess =  (const char *)ADDED  				   +\
	  	  	  to_string(char( (*pos)/100      ))   +\
	  	  	  to_string(char( ((*pos)%100)/10 ))   +\
	  	  	  to_string(char( ((*pos)%100)%10 ));
	 strcpy( text,  mess.c_str() );
	 HAL_IWDG_Refresh(&hiwdg);
	 return true;
}

bool PhoneBook::SaveSettings(){
	  uint32_t address = SettBank;

	  EE_ClearPage(address);

	  EE_WriteVariable(address,   uint16_t( Settings.Pass[3] ) + uint16_t( Settings.Pass[2]<<8) );
	  EE_WriteVariable(address+2, uint16_t( Settings.Pass[1] ) + uint16_t( Settings.Pass[0]<<8) );
	  EE_WriteVariable(address+4, uint16_t( Settings.RelayOnTime ) );
	  EE_WriteVariable(address+8, uint16_t( Settings.AccessAlarm ) );

	  return true;
}

bool PhoneBook::ReadSettings(){
	  uint32_t address = SettBank;
	  uint16_t temp;

	  temp = EE_ReadVariable(address);
	  if (temp == ERASED){return false;}
	  Settings.Pass[3] = char(temp & 0x00FF);
	  Settings.Pass[2] = char( (temp & 0xFF00) >> 8);

	  temp = EE_ReadVariable(address+2);
	  Settings.Pass[1] = char(temp & 0x00FF);
	  Settings.Pass[0] = char( (temp & 0xFF00) >> 8);

	  temp = EE_ReadVariable(address+4);
	  Settings.RelayOnTime = uint8_t(temp);

	  temp = EE_ReadVariable(address+8);
	  Settings.AccessAlarm = uint8_t(temp);
	  HAL_IWDG_Refresh(&hiwdg);
	  return true;
}
bool PhoneBook::ClearMemory(){
		EE_ClearPage(Bank170);
		EE_ClearPage(Bank340);
		EE_ClearPage(Bank510);
		EE_ClearPage(Bank680);
		return true;
}
uint32_t PhoneBook::_GetPage(uint16_t position){
	 string LOG;
	 if 	 (position<171				   ){return Bank170;}
	 if 	 (position>=171 && position<341){return Bank340;}
	 if      (position>=341 && position<511){return Bank510;}
	 if      (position>=511 && position<681){return Bank680;}
}
